"use client"

import { useState } from "react"
import { BirthdayPicker, type BirthdayData } from "./birthday-picker"
import { PreferenceSelector } from "./preference-selector"
import { cn } from "@/lib/utils"

export function NamingForm() {
  const [surname, setSurname] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [nameType, setNameType] = useState<"double" | "single">("double")
  const [generationChar, setGenerationChar] = useState("")
  const [charPosition, setCharPosition] = useState<"middle" | "last">("middle")
  const [birthdayPickerOpen, setBirthdayPickerOpen] = useState(false)
  const [birthdayData, setBirthdayData] = useState<BirthdayData | null>(null)
  const [selectedPreferences, setSelectedPreferences] = useState<string[]>(["poetry"])
  const [keywords, setKeywords] = useState("")

  const togglePreference = (pref: string) => {
    setSelectedPreferences(prev => 
      prev.includes(pref) 
        ? prev.filter(p => p !== pref)
        : [...prev, pref]
    )
  }

  const formatBirthday = () => {
    if (!birthdayData) return "请选择出生时间"
    
    const { calendarType, year, month, day, hour, minute } = birthdayData
    
    if (calendarType === "gregorian") {
      return `公历 ${year}年${month}月${day}日 ${hour} ${minute}`
    } else {
      return `农历 ${year}年${month}${day} ${hour} ${minute}`
    }
  }

  const handleSubmit = () => {
    console.log({
      surname,
      gender,
      nameType,
      generationChar,
      charPosition,
      birthdayData,
      selectedPreferences,
      keywords
    })
    alert("开始取名！")
  }

  return (
    <div className="min-h-screen bg-stone-100 py-8 px-4">
      {/* Main Container with Chinese Border */}
      <div className="max-w-3xl mx-auto relative">
        {/* Decorative Border */}
        <div className="absolute inset-0 border-8 border-red-700 rounded-lg">
          {/* Corner Decorations */}
          <div className="absolute -top-1 -left-1 w-12 h-12 border-t-4 border-l-4 border-red-800" />
          <div className="absolute -top-1 -right-1 w-12 h-12 border-t-4 border-r-4 border-red-800" />
          <div className="absolute -bottom-1 -left-1 w-12 h-12 border-b-4 border-l-4 border-red-800" />
          <div className="absolute -bottom-1 -right-1 w-12 h-12 border-b-4 border-r-4 border-red-800" />
          
          {/* Inner Pattern Lines */}
          <div className="absolute top-3 left-3 right-3 border-t-2 border-red-600/50" />
          <div className="absolute bottom-3 left-3 right-3 border-b-2 border-red-600/50" />
          <div className="absolute top-3 bottom-3 left-3 border-l-2 border-red-600/50" />
          <div className="absolute top-3 bottom-3 right-3 border-r-2 border-red-600/50" />
        </div>

        {/* Corner Dots */}
        <div className="absolute top-6 left-6 w-3 h-3 rounded-full bg-red-700" />
        <div className="absolute top-6 right-6 w-3 h-3 rounded-full bg-red-700" />
        <div className="absolute bottom-6 left-6 w-3 h-3 rounded-full bg-red-700" />
        <div className="absolute bottom-6 right-6 w-3 h-3 rounded-full bg-red-700" />

        {/* Content */}
        <div className="relative bg-stone-200/80 rounded-lg p-8 pt-12">
          {/* Section Label - 必填信息 */}
          <div className="absolute left-8 top-16">
            <div className="bg-gradient-to-b from-red-700 to-red-800 text-white px-3 py-6 rounded-lg shadow-lg">
              <div className="writing-vertical text-lg font-bold tracking-widest">
                必填信息
              </div>
            </div>
          </div>

          {/* Form Fields */}
          <div className="ml-20 space-y-6">
            {/* 姓氏 */}
            <div className="flex items-center gap-4">
              <label className="w-20 text-right text-gray-700 font-medium">
                姓&nbsp;&nbsp;&nbsp;&nbsp;氏:
              </label>
              <input
                type="text"
                value={surname}
                onChange={(e) => setSurname(e.target.value)}
                className="w-40 px-4 py-2 border border-gray-300 bg-white rounded focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="请输入姓氏"
              />
            </div>

            {/* 性别 */}
            <div className="flex items-center gap-4">
              <label className="w-20 text-right text-gray-700 font-medium">
                性&nbsp;&nbsp;&nbsp;&nbsp;别:
              </label>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={gender === "male"}
                    onChange={() => setGender("male")}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <span className="text-gray-700">男</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={gender === "female"}
                    onChange={() => setGender("female")}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <span className="text-gray-700">女</span>
                </label>
              </div>
            </div>

            {/* 生日 */}
            <div className="flex items-center gap-4">
              <label className="w-20 text-right text-gray-700 font-medium">
                生&nbsp;&nbsp;&nbsp;&nbsp;日:
              </label>
              <button
                onClick={() => setBirthdayPickerOpen(true)}
                className={cn(
                  "px-4 py-2 border border-gray-300 bg-white rounded text-left min-w-[280px]",
                  "hover:border-red-400 transition-colors",
                  birthdayData ? "text-gray-900" : "text-red-500"
                )}
              >
                {formatBirthday()}
              </button>
            </div>

            {/* 名字类型 */}
            <div className="flex items-center gap-4">
              <label className="w-20 text-right text-gray-700 font-medium">
                名字类型:
              </label>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={nameType === "double"}
                    onChange={() => setNameType("double")}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <span className="text-gray-700">双字名（如：刘德华）</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={nameType === "single"}
                    onChange={() => setNameType("single")}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <span className="text-gray-700">单字名（如：朱茵）</span>
                </label>
              </div>
            </div>

            {/* 字辈 */}
            <div className="flex items-center gap-4">
              <label className="w-20 text-right font-medium">
                <span className="text-red-500">字辈</span>:
              </label>
              <input
                type="text"
                value={generationChar}
                onChange={(e) => setGenerationChar(e.target.value)}
                className="w-20 px-4 py-2 border border-gray-300 bg-white rounded focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
              <select
                value={charPosition}
                onChange={(e) => setCharPosition(e.target.value as "middle" | "last")}
                className="px-4 py-2 border border-gray-300 bg-white rounded focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="middle">固定中间</option>
                <option value="last">固定末尾</option>
              </select>
              <span className="text-blue-500 text-sm">没有固定字可不填写</span>
            </div>
          </div>

          {/* Divider */}
          <div className="my-8 border-t border-red-300" />

          {/* 偏好选择 Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-red-800 flex items-center gap-2">
              <span className="w-1 h-5 bg-red-700 rounded-full" />
              偏好选择
            </h3>
            <PreferenceSelector
              selectedPreferences={selectedPreferences}
              onToggle={togglePreference}
              keywords={keywords}
              onKeywordsChange={setKeywords}
            />
          </div>

          {/* Submit Button */}
          <div className="mt-10 flex justify-center">
            <button
              onClick={handleSubmit}
              className="px-16 py-4 bg-gradient-to-b from-red-700 to-red-800 text-white text-xl font-bold rounded-lg shadow-lg hover:from-red-800 hover:to-red-900 transition-all transform hover:scale-105"
            >
              开始取名
            </button>
          </div>
        </div>
      </div>

      {/* Birthday Picker Modal */}
      <BirthdayPicker
        isOpen={birthdayPickerOpen}
        onClose={() => setBirthdayPickerOpen(false)}
        onConfirm={setBirthdayData}
        initialData={birthdayData || undefined}
      />
    </div>
  )
}
