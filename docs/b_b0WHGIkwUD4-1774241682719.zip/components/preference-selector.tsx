"use client"

import { cn } from "@/lib/utils"

interface PreferenceSelectorProps {
  selectedPreferences: string[]
  onToggle: (preference: string) => void
  keywords: string
  onKeywordsChange: (value: string) => void
}

const preferences = [
  { id: "poetry", label: "诗词起名", icon: "📜" },
  { id: "phonetic", label: "音形义起名", icon: "🔊" },
  { id: "zodiac", label: "生肖起名", icon: "🐉" },
  { id: "bigdata", label: "大数据起名", icon: "📊" },
  { id: "expectation", label: "期望起名", icon: "✨" },
  { id: "flora", label: "花草起名", icon: "🌸" },
]

export function PreferenceSelector({ 
  selectedPreferences, 
  onToggle, 
  keywords, 
  onKeywordsChange 
}: PreferenceSelectorProps) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        {preferences.map((pref) => (
          <button
            key={pref.id}
            onClick={() => onToggle(pref.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium transition-all",
              "border shadow-sm",
              selectedPreferences.includes(pref.id)
                ? "bg-amber-50 border-amber-300 text-amber-800"
                : "bg-amber-50/50 border-amber-200/50 text-amber-700 hover:bg-amber-50 hover:border-amber-300"
            )}
          >
            <span>{pref.icon}</span>
            <span>{pref.label}</span>
          </button>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 text-sm text-amber-700 whitespace-nowrap">
          <span>🌙</span>
          <span>个性补充 (诗词/花草关键词):</span>
        </div>
        <input
          type="text"
          value={keywords}
          onChange={(e) => onKeywordsChange(e.target.value)}
          placeholder="如: 清莲, 明德, 鹤影, 竹韵, 静秋"
          className="flex-1 px-4 py-2.5 rounded-full border border-amber-200 bg-white text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-300 focus:border-amber-300"
        />
      </div>
    </div>
  )
}
