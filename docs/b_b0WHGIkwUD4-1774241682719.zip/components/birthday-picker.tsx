"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"

interface BirthdayPickerProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (data: BirthdayData) => void
  initialData?: BirthdayData
}

export interface BirthdayData {
  calendarType: "gregorian" | "lunar"
  year: number
  month: number | string
  day: number | string
  hour: number | string
  minute: number | string
}

const gregorianMonths = Array.from({ length: 12 }, (_, i) => `${i + 1}月`)
const gregorianDays = Array.from({ length: 31 }, (_, i) => `${i + 1}日`)
const lunarMonths = ["正月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "冬月", "腊月"]
const lunarDays = [
  "初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十",
  "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十",
  "廿一", "廿二", "廿三", "廿四", "廿五", "廿六", "廿七", "廿八", "廿九", "三十"
]
const hours = ["未知", "0时", "1时", "2时", "3时", "4时", "5时", "6时", "7时", "8时", "9时", "10时", "11时", "12时", "13时", "14时", "15时", "16时", "17时", "18时", "19时", "20时", "21时", "22时", "23时"]
const lunarHours = ["未知", "0子时", "1丑时", "2丑时", "3寅时", "4寅时", "5卯时", "6卯时", "7辰时", "8辰时", "9巳时", "10巳时", "11午时", "12午时", "13未时", "14未时", "15申时", "16申时", "17酉时", "18酉时", "19戌时", "20戌时", "21亥时", "22亥时", "23亥时"]
const minutes = ["未知", ...Array.from({ length: 60 }, (_, i) => `${i}分`)]
const currentYear = new Date().getFullYear()
const years = Array.from({ length: 100 }, (_, i) => currentYear - i + 5)

function ScrollColumn({ 
  items, 
  selectedIndex, 
  onSelect 
}: { 
  items: (string | number)[]
  selectedIndex: number
  onSelect: (index: number) => void 
}) {
  const containerRef = useRef<HTMLDivElement>(null)
  const itemHeight = 44

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTo({
        top: selectedIndex * itemHeight,
        behavior: "smooth"
      })
    }
  }, [selectedIndex])

  const handleScroll = () => {
    if (containerRef.current) {
      const scrollTop = containerRef.current.scrollTop
      const newIndex = Math.round(scrollTop / itemHeight)
      if (newIndex !== selectedIndex && newIndex >= 0 && newIndex < items.length) {
        onSelect(newIndex)
      }
    }
  }

  return (
    <div className="relative h-[132px] flex-1">
      <div className="absolute inset-x-0 top-[44px] h-[44px] bg-gray-100 pointer-events-none z-0" />
      <div 
        ref={containerRef}
        className="h-full overflow-y-auto scrollbar-hide relative z-10"
        onScroll={handleScroll}
        style={{ scrollSnapType: "y mandatory" }}
      >
        <div className="h-[44px]" />
        {items.map((item, index) => (
          <div
            key={index}
            className={cn(
              "h-[44px] flex items-center justify-center cursor-pointer transition-all",
              "text-base",
              index === selectedIndex ? "text-gray-900 font-medium" : "text-gray-400"
            )}
            style={{ scrollSnapAlign: "center" }}
            onClick={() => onSelect(index)}
          >
            {item}
          </div>
        ))}
        <div className="h-[44px]" />
      </div>
    </div>
  )
}

export function BirthdayPicker({ isOpen, onClose, onConfirm, initialData }: BirthdayPickerProps) {
  const now = new Date()
  const [calendarType, setCalendarType] = useState<"gregorian" | "lunar">(initialData?.calendarType || "gregorian")
  const [yearIndex, setYearIndex] = useState(() => {
    const year = initialData?.year || now.getFullYear()
    const index = years.indexOf(year)
    return index >= 0 ? index : 5
  })
  const [monthIndex, setMonthIndex] = useState(() => {
    if (typeof initialData?.month === "number") {
      return initialData.month - 1
    }
    return now.getMonth()
  })
  const [dayIndex, setDayIndex] = useState(() => {
    if (typeof initialData?.day === "number") {
      return initialData.day - 1
    }
    return now.getDate() - 1
  })
  const [hourIndex, setHourIndex] = useState(() => {
    return now.getHours() + 1
  })
  const [minuteIndex, setMinuteIndex] = useState(() => {
    return now.getMinutes() + 1
  })

  if (!isOpen) return null

  const currentMonths = calendarType === "gregorian" ? gregorianMonths : lunarMonths
  const currentDays = calendarType === "gregorian" ? gregorianDays : lunarDays
  const currentHours = calendarType === "gregorian" ? hours : lunarHours

  const formatDisplay = () => {
    const year = years[yearIndex]
    const month = currentMonths[monthIndex]
    const day = currentDays[dayIndex]
    const hour = currentHours[hourIndex]
    const minute = minutes[minuteIndex]
    
    if (calendarType === "gregorian") {
      return `公历:${year}年${month.replace("月", "")}月${day.replace("日", "")}日 ${hour === "未知" ? "未知" : hour.replace("时", "")}时${minute === "未知" ? "未知" : minute.replace("分", "")}分`
    } else {
      return `农历:${year}年${month}${day} ${hour === "未知" ? "未知" : hour}${minute === "未知" ? "未知" : minute.replace("分", "")}分`
    }
  }

  const handleConfirm = () => {
    onConfirm({
      calendarType,
      year: years[yearIndex],
      month: calendarType === "gregorian" ? monthIndex + 1 : currentMonths[monthIndex],
      day: calendarType === "gregorian" ? dayIndex + 1 : currentDays[dayIndex],
      hour: currentHours[hourIndex],
      minute: minutes[minuteIndex]
    })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50" onClick={onClose}>
      <div 
        className="w-full max-w-lg bg-white rounded-t-2xl animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="py-4 text-center border-b border-gray-100">
          <p className="text-lg font-medium text-gray-900">{formatDisplay()}</p>
        </div>

        {/* Calendar Type Tabs */}
        <div className="flex mx-4 mt-4 border border-red-600 rounded-lg overflow-hidden">
          <button
            className={cn(
              "flex-1 py-3 text-base font-medium transition-colors",
              calendarType === "gregorian" 
                ? "bg-red-600 text-white" 
                : "bg-white text-red-600"
            )}
            onClick={() => setCalendarType("gregorian")}
          >
            公历
          </button>
          <button
            className={cn(
              "flex-1 py-3 text-base font-medium transition-colors",
              calendarType === "lunar" 
                ? "bg-red-600 text-white" 
                : "bg-white text-red-600"
            )}
            onClick={() => setCalendarType("lunar")}
          >
            农历
          </button>
        </div>

        {/* Scroll Picker */}
        <div className="flex px-4 py-4 gap-1">
          <ScrollColumn 
            items={years} 
            selectedIndex={yearIndex} 
            onSelect={setYearIndex} 
          />
          <ScrollColumn 
            items={currentMonths} 
            selectedIndex={monthIndex} 
            onSelect={setMonthIndex} 
          />
          <ScrollColumn 
            items={currentDays} 
            selectedIndex={dayIndex} 
            onSelect={setDayIndex} 
          />
          <ScrollColumn 
            items={currentHours} 
            selectedIndex={hourIndex} 
            onSelect={setHourIndex} 
          />
          <ScrollColumn 
            items={minutes} 
            selectedIndex={minuteIndex} 
            onSelect={setMinuteIndex} 
          />
        </div>

        {/* Action Buttons */}
        <div className="flex border-t border-gray-200">
          <button
            className="flex-1 py-4 text-base text-gray-600 font-medium border-r border-gray-200"
            onClick={onClose}
          >
            取消
          </button>
          <button
            className="flex-1 py-4 text-base text-gray-900 font-medium"
            onClick={handleConfirm}
          >
            确定
          </button>
        </div>
      </div>
    </div>
  )
}
