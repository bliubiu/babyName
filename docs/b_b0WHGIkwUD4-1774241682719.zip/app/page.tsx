import { NamingForm } from "@/components/naming-form"

export default function Home() {
  return (
    <main>
      <NamingForm />
    </main>
  )
}
